(function(){
	var gulp = require('gulp'),
		sass = require('gulp-sass'),
		rev = require('gulp-rev'),
		rename = require('gulp-rename');	
	var filePath = {
		srcpath:  '../app/scss/*.scss',
		destpath: '../final/css'
	};
	//Compiling SCSS Files
	gulp.task('compile-sass', function () {
	  return gulp.src(filePath.srcpath)    
		.pipe(sass({outputStyle: 'compressed'}).on('error', sass.logError))
		.pipe(rename('cbdt.css'))		  
		.pipe(rev())
		.pipe(gulp.dest(filePath.destpath));
	});
})();