(function(){
	var gulp = require('gulp'),
		htmlmin = require('gulp-htmlmin');
	var filePath = {
	  srcpath:  '../app/html/*.html',
	  destpath: '../final/html'
	};
	//Defining the build html task
	gulp.task('build-html', function () {      
		  return gulp.src(filePath.srcpath)	  
		  .pipe(htmlmin({collapseWhitespace: true}))
		  .pipe(gulp.dest(filePath.destpath));
	});
})();