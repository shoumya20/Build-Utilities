(function(){
	var gulp = require('gulp'),
		del = require('del');
	var filePath = {  
	  destpath: '../final/**'
	};
	//remove the final folder
	gulp.task('clean', function (cb) {
		console.log("########## Cleaning the Build Now ###############");		
		del([filePath.destpath],{force: true},cb);
	});
})();