(function(){
	var gulp = require('gulp'),
		express = require('express'),
		port = process.env.PORT || 5000;
	var filePath = {
		indexfile:  '../app/html/'
	};
	//Define the task express 
	gulp.task('express', function () {    
		app = express();
		app.use(express.static(filePath.indexfile));
		app.listen(port, function () {
			console.log("####### NodeJs Server started on the port  " + port);
			console.log("####### Front End Development CBDT");
			console.log("Node Js Version .........."+process.version);
			console.log("Operating system Platform ......"+process.platform);
			console.log("Operating System Architecture..."+process.arch);
			console.log("####### To Run ::::: Open your browser and type http://localhost:5000/ ###############");
		});
	});
	//Default Gulp Task Defined
	gulp.task('default', ['express'], function () {
	   console.log("############## Default Gulp Task is Started ##############");
	});
})();