(function () {
	var gulp = require('gulp'),
		jshint = require("gulp-jshint");
	var filePath = {
		srcpath: '../app/js/*.js',
		reportpath: '../jshint-output.html',
		jshintrcpath: './.jshintrc'
	};
	//jshint -stylish
	gulp.task('jshint-stylish', function () {
		gulp.src(filePath.srcpath)
			.pipe(jshint('.jshintrc'))
			.pipe(jshint.reporter('jshint-stylish'))
	});
})();