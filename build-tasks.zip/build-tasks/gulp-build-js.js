(function () {
	var gulp = require('gulp'),
		removelogs = require('gulp-strip-debug'),
		uglifyref = require('gulp-uglify'),
		rev = require('gulp-rev');
	var filePath = {
		srcpath: '../app/js/*.js',
		destpath: '../final/js'
	};
	//Defining the js build process
	gulp.task('build-js', function () {
		return gulp.src(filePath.srcpath)
			.pipe(removelogs())
			.pipe(uglifyref())
			.pipe(rev())
			.pipe(concat('all.js'))
			.pipe(gulp.dest(filePath.destpath));
	});
})();