(function () {
	var gulp = require('gulp'),
		  jscs = require('gulp-jscs');
	var filePath = {
		srcpath: '../app/js/*.js',
		destpath: '../final/js'
	};
	//Defining the js build process
	gulp.task('build-jscs', function () {
		return gulp.src(filePath.srcpath)
			.pipe(jscs({ fix: true }))
			.pipe(jscs.reporter())
			.pipe(jscs.reporter('fail'))
			.pipe(gulp.dest(filePath.destpath));
	});
})();