(function () {
	var gulp = require('gulp'),
		jshint = require("gulp-jshint");
	var filePath = {
		srcpath: '../app/js/*.js',
		reportpath: '../jshint-output.html',
		jshintrcpath: './.jshintrc'
	};
	//jslinting reporting output in separate file
	gulp.task("jshint-report", function () {
		console.log("########## Linting Issues ###############");
		gulp.src(filePath.srcpath)
			.pipe(jshint(filePath.jshintrcpath))
			.pipe(jshint())
			.pipe(jshint.reporter('gulp-jshint-html-reporter', {
				filename: filePath.reportpath,
				createMissingFolders: false
			}));
	});
	//jshint command line
	gulp.task("jshint", function () {
		console.log("########## Linting Issues ###############");
		gulp.src(filePath.srcpath)
			.pipe(jshint(filePath.jshintrcpath))
			.pipe(jshint())
			.pipe(jshint.reporter("default"));
	});
	//jshint -stylish
	gulp.task('jshint-stylish', function () {
		gulp.src(filePath.srcpath)
			.pipe(jshint('.jshintrc'))
			.pipe(jshint.reporter('jshint-stylish'))
	});
})();