(function () {
	var gulp = require('gulp'),
		htmlhint = require('gulp-htmlhint');
	var filePath = {
		srcpath: '../app/html/*.html',
		destpath: '../final/html'
	};
	//Defining the build html task
	gulp.task('html-hint', function () {
		  return gulp.src(filePath.srcpath)
			.pipe(htmlhint('./.htmlhintrc'))
			.pipe(htmlhint())
			.pipe(htmlhint.reporter())
	});
})();