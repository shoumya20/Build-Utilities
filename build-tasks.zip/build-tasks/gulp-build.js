(function(){
	var gulp = require('gulp');
	//Defining the build task and the adding the sub tasks as dependencies
	gulp.task("build",['build-js','build-html','compile-sass'],function(){
	   console.log("############## Generating Build Task ##############");
	});
})();