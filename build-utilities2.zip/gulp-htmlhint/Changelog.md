
0.3.0 / 2015-07-18
==================

  * Merge pull request #15 from doshprompt/require-reporter
  * Merge pull request #16 from doshprompt/fail-reporter
  * feat(failReporter): use suppress=true instead of errors=false
  * Update README.md
  * chore(README): more details on failReporter
  * feat(failReporter): add ability to turn off file errors on failure
  * test(reporter): load custom reporter by package name
  * feat(reporter): custom reporter can be loaded by its package name

0.2.1 / 2015-07-17
==================

  * feat(htmlhintrc): allow comments similar to jshintrc
