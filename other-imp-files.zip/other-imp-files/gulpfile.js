(function(){
	//Define the dependent libraries
	var gulp = require('gulp'),   	
		requireDir = require('require-dir'),
		dir = requireDir('build-tasks', {recurse: true});
})();