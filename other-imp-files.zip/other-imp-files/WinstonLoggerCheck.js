/*
var winston = require('winston');
winston.log('info', 'Hello distributed log files!');
winston.info('Hello again distributed logs');

winston.add(winston.transports.File, { filename: 'somefile.log' });
winston.remove(winston.transports.Console);
*/
var winston = require('winston');
//User can write to the console and also to the File if he wants
var logger = new (winston.Logger)({
    transports: [
      //new (winston.transports.Console)(),
      new (winston.transports.File)({ filename: 'mylogger.log' })
    ]
  });

//Writing some logs here  
//Specify the log type over here
logger.log('info', 'Hello distributed log files!');
winston.log('info', 'Test Log Message', { anything: 'This is metadata' });
logger.info('Hello again distributed logs');

var logger2 = new (winston.Logger)({
  transports: [
    new (winston.transports.File)({
      name: 'info-file',
      filename: 'filelog-info.log',
      level: 'info'
    }),
    new (winston.transports.File)({
      name: 'error-file',
      filename: 'filelog-error.log',
      level: 'error'
    })
  ]
});

logger2.log('info', 'Hello distributed log files!');
logger2.log('error', 'Error Log Files!');
winston.log('info', 'Test Log Message', { anything: 'This is metadata' });
logger2.info('Hello again distributed logs');
logger2.error('Error Logs');